//
//  c_pythonTests.m
//  c_pythonTests
//
//  Created by srplab on 12-7-8.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import "c_pythonTests.h"

@implementation c_pythonTests

- (void)setUp
{
    [super setUp];
    
    // Set-up code here.
}

- (void)tearDown
{
    // Tear-down code here.
    
    [super tearDown];
}

- (void)testExample
{
    STFail(@"Unit tests are not implemented yet in c_pythonTests");
}

@end
