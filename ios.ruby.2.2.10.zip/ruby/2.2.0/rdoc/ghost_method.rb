##
# GhostMethod represents a method referenced only by a comment

class RDoc::GhostMethod < RDoc::AnyMethod
end

