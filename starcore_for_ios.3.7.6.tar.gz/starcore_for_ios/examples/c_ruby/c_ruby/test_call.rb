puts $CClass

val = $CClass.new("from ruby")
puts(val)
val.callback(1234.4564)
val.callback("sdfsdfsdfsdf")
val.SetRubyObject(File);
puts("===========end=========")