//
//  ViewController.m
//  call_lua_dylib
//
//  Created by srplab on 13-11-29.
//  Copyright (c) 2013年 srplab. All rights reserved.
//

#import "ViewController.h"
#include "vsopenapi.h"

static class ClassOfSRPInterface *SRPInterface;

static VS_UWORD MsgCallBack( VS_ULONG ServiceGroupID, VS_ULONG uMsg, VS_UWORD wParam, VS_UWORD lParam, VS_BOOL &IsProcessed, VS_UWORD Para )
{
    switch( uMsg ){
        case MSG_VSDISPMSG :
        case MSG_VSDISPLUAMSG :
            printf("[core]%s\n",(VS_CHAR *)wParam);
            break;
        case MSG_DISPMSG :
        case MSG_DISPLUAMSG :
            printf("%s\n",(VS_CHAR *)wParam);
            break;
    }
    return 0;
}

static VS_INT32 Add(void *Object,VS_INT32 x,VS_INT32 y)
{
    SRPInterface ->Print("Call From ios, %d,%d",x,y);
    return x + y;
}

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory,   NSUserDomainMask, YES);
    NSString *documentsDirectory = [paths objectAtIndex:0];
    
    const char* destDir = [documentsDirectory UTF8String];
    VS_BOOL Result = StarCore_Init((VS_CHAR *)destDir);
    
    VSCore_Init( true, true, "", 0, "", 0,NULL);
    printf("init starcore success\n");
    
    class ClassOfSRPControlInterface *SRPControlInterface = NULL;
    class ClassOfBasicSRPInterface *BasicSRPInterface = NULL;
    
    SRPControlInterface = VSCore_QueryControlInterface();
    BasicSRPInterface = SRPControlInterface ->QueryBasicInterface(0);
    BasicSRPInterface ->CreateService("", "test", NULL, "123", 0, 0, 0, 0, 0, 0);
    SRPInterface = BasicSRPInterface ->GetSRPInterface("test", "root", "123");
    BasicSRPInterface -> Release();
    //VSCoreLib_InitSimple(&Context,"test","123",0,0,MsgCallBack,0,NULL);
    
    VS_CHAR LuaBuf[512];
    sprintf(LuaBuf,"print(\"hello from lua\")");
    SRPInterface ->DoBuffer("lua",LuaBuf,strlen(LuaBuf),"", NULL, NULL, VS_FALSE);
    
    sprintf(LuaBuf,"SrvGroup = libstarcore._GetSrvGroup()\n");
    strcat(LuaBuf,"Service = SrvGroup:_GetService(\"\",\"\")\n");
    strcat(LuaBuf,"Obj=Service:_New(\"TestClass\");\n");
    strcat(LuaBuf,"function Obj:Add(x,y)\n");
    strcat(LuaBuf,"  local cobj=self._Service.TestClassC:_New();\n");
    strcat(LuaBuf,"  print(cobj:Add(x,y))\n");
    strcat(LuaBuf,"  cobj:_Free()\n");
    strcat(LuaBuf,"  return x+y;\n");
    strcat(LuaBuf,"end\n");
    
    SRPInterface ->CheckPassword(VS_FALSE);
    SRPInterface ->DoBuffer((VS_CHAR*)"lua",LuaBuf,strlen(LuaBuf),(VS_CHAR*)"", NULL, NULL, VS_FALSE);
    
    void *AtomicClass = SRPInterface ->CreateAtomicObjectSimple((VS_CHAR*)"TestItem",(VS_CHAR*)"TestClassC",NULL,NULL,NULL);
    SRPInterface ->CreateAtomicFunctionSimpleEx(AtomicClass,(VS_CHAR*)"Add",(VS_CHAR*)"VS_INT32 Add(VS_INT32 x,VS_INT32 y);",(void *)Add,NULL);
    
    void *Class,*Object;
	Class = SRPInterface ->GetObjectEx(NULL,(VS_CHAR*)"TestClass");
	Object = SRPInterface ->MallocObjectL( SRPInterface->GetIDEx(Class),0,NULL);
	printf("Call Function Ret = %lu\n",SRPInterface ->ScriptCall(Object,NULL,(VS_CHAR*)"Add",(VS_CHAR*)"(ii)i",12,34));
    
    /*---call lua raw function---*/
    sprintf(LuaBuf,"function RawAdd(x,y)\n");
    strcat(LuaBuf,"  print(\"call raw function\")\n");
    strcat(LuaBuf,"  return x+y;\n");
    strcat(LuaBuf,"end\n");
    
    SRPInterface ->DoBuffer((VS_CHAR*)"lua",LuaBuf,strlen(LuaBuf),(VS_CHAR*)"", NULL, NULL, VS_FALSE);
    BasicSRPInterface = SRPInterface ->GetBasicInterface();
    BasicSRPInterface ->InitRaw("lua",SRPInterface);
    void *lua = SRPInterface ->ImportRawContext("lua","",false,NULL);
    printf("Call raw lua add function = %d\n",(VS_INT32)SRPInterface->ScriptCall(lua,NULL,"RawAdd","(ii)i",234,567));
    
    char *LocalIP = BasicSRPInterface ->GetLocalIP();
    SOCKADDR_IN LocalIP1[64];
    int Number = BasicSRPInterface->GetLocalIPEx(LocalIP1,64);
    
	SRPInterface -> Release();
    //	VSCoreLib_TermSimple(&Context);
    VSCore_Term();
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
