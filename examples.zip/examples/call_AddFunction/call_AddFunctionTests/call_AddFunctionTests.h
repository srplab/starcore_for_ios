//
//  call_AddFunctionTests.h
//  call_AddFunctionTests
//
//  Created by srplab on 11/27/12.
//  Copyright (c) 2012 srplab. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>

@interface call_AddFunctionTests : SenTestCase

@end
