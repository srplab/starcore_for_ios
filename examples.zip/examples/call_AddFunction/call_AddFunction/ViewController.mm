//
//  ViewController.m
//  call_AddFunction
//
//  Created by srplab on 11/27/12.
//  Copyright (c) 2012 srplab. All rights reserved.
//

#import "ViewController.h"
#include "vsopenapi.h"

static class ClassOfSRPInterface *SRPInterface;

static VS_UWORD MsgCallBack( VS_ULONG ServiceGroupID, VS_ULONG uMsg, VS_UWORD wParam, VS_UWORD lParam, VS_BOOL *IsProcessed, VS_UWORD Para )
{
    switch( uMsg ){
        case MSG_VSDISPMSG :
        case MSG_VSDISPLUAMSG :
            printf("[core]%s\n",(VS_CHAR *)wParam);
            break;
        case MSG_DISPMSG :
        case MSG_DISPLUAMSG :
            printf("%s\n",(VS_CHAR *)wParam);
            break;
    }
    return 0;
}

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory,   NSUserDomainMask, YES);
    NSString *documentsDirectory = [paths objectAtIndex:0];
    
    const char* destDir = [documentsDirectory UTF8String];
    VS_BOOL Result = StarCore_Init((VS_CHAR *)destDir);
    
    VS_CORESIMPLECONTEXT Context;
    
    SRPInterface = VSCoreLib_InitSimple(&Context,"test","123",0,0,MsgCallBack,0,"AddFunction.dylib",NULL);
    
    void *Class,*Object;
    Class = SRPInterface ->GetObjectEx(NULL,"TestClass");
	Object = SRPInterface ->MallocObjectL( SRPInterface->GetIDEx(Class),0,NULL);
    
	printf("Call Function Ret = %lu\n",SRPInterface ->ScriptCall(Object,NULL,"Add","(ii)i",12,34));
    
	SRPInterface -> Release();
	VSCore_TermSimple(&Context);
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
