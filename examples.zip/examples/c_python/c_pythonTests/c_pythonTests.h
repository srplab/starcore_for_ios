//
//  c_pythonTests.h
//  c_pythonTests
//
//  Created by srplab on 12-7-8.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>

@interface c_pythonTests : SenTestCase

@end
