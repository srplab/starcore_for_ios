//
//  call_luapkgTests.m
//  call_luapkgTests
//
//  Created by srplab on 11/27/12.
//  Copyright (c) 2012 srplab. All rights reserved.
//

#import "call_luapkgTests.h"

@implementation call_luapkgTests

- (void)setUp
{
    [super setUp];
    
    // Set-up code here.
}

- (void)tearDown
{
    // Tear-down code here.
    
    [super tearDown];
}

- (void)testExample
{
    XCTFail(@"Unit tests are not implemented yet in call_luapkgTests");
}

@end
