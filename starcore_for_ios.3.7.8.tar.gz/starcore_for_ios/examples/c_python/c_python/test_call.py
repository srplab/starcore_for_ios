import imp  #test load path

import json
print(CClass)

val = CClass("from python")
val.callback(1234.4564)
val.callback("sdfsdfsdfsdf")
val.SetPythonObject(json);
print("===========end=========")