//
//  main.m
//  call_lua_dylib
//
//  Created by srplab on 13-11-29.
//  Copyright (c) 2013年 srplab. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "AppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
